package com.example.ut4_recyclerview

class Color(val nombre: String , val codigoHex : String)
