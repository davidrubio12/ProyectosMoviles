package com.example.proyectodemoviles.model.dto

data class RegisterUserDto(
    val username: String,
    val password: String,

)