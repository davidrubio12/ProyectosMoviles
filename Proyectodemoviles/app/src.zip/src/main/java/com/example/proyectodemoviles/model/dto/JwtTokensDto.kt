package com.example.proyectodemoviles.model.dto

data class JwtTokensDto (
    val accessToken: String,
    val refreshToken: String
    )