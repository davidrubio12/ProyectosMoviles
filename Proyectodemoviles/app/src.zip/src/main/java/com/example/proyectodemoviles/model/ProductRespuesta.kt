package com.example.proyectodemoviles.model

data class ProductRespuesta(val status:String, val message: List<String>?) {
}