package com.example.proyectodemoviles.model.dto

data class LoginUserDto (
    val email: String,
    val password: String
)


