package com.example.proyectodemoviles.data

object Util {
    var accessToken : String = ""
}